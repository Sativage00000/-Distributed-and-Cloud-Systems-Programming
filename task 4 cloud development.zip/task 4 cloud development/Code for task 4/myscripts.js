// script.js

// Import required Firebase services
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-app.js";
import { Firestore, 
         getFirestore, 
         onSnapshot, 
         query, 
         collection, 
         orderBy,
         addDoc,
         deleteDoc,
         doc } from 'https://www.gstatic.com/firebasejs/9.18.0/firebase-firestore.js';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAPgdi5CoUSiKO-Kso8Fd7WTZlaz-dWXLM",
  authDomain: " csc5cs022--2326310.firebaseapp.com",
  projectId: "csc5cs022--2326310",
  storageBucket: "csc5cs022--2326310.appspot.com",
  messagingSenderId: "549755206319",
  appId: "1:549755206319:web:87116904c99d4cc3d5325a",
};
// Initialize Firebase
const app = initializeApp(firebaseConfig);    
const db = getFirestore(app);    

// Get a live data snapshot (i.e. auto-refresh) of our Reviews collection
const q = query(collection(db, "Reviews"), orderBy("Movie_name"));

// Listen for changes in the Reviews collection
const unsubscribe = onSnapshot(q, (snapshot) => {
  // Empty HTML table
  $('#reviewList').empty();

  // Loop through snapshot data and add to HTML table
  snapshot.forEach((doc) => {
    const movieName = doc.data().Movie_name;
    const movieRating = doc.data().Movie_Rating;
    const movieId = doc.id;

    const row = $('<tr>');
    row.append('<td>' + movieName + '</td>');
    row.append('<td>' + movieRating + '/5</td>');
    row.append('<td><button class="btn btn-danger deleteBtn" data-id="' + movieId + '">Delete</button></td>');

    $('#reviewList').append(row);
  });

  // Display review count
  $('#mainTitle').html(snapshot.size + " Movie reviews in the list");
});  

// Add movie button click event
$('#addMovieBtn').click(function() {
  const movieName = prompt("Enter movie name:");
  const movieRating = parseFloat(prompt("Enter movie rating (out of 5):"));

  // Check if inputs are valid
  if (movieName && !isNaN(movieRating) && movieRating > 0 && movieRating <= 5) {
    addDoc(collection(db, "Reviews"), {
      Movie_name: movieName,
      Movie_Rating: movieRating
    });
  } else {
    alert("Invalid input! Movie rating must be a number between 0 and 5.");
  }
});

// Delete movie button click event
$(document).on('click', '.deleteBtn', function() {
  const movieId = $(this).data('id');
  deleteDoc(doc(db, "Reviews", movieId));
});
